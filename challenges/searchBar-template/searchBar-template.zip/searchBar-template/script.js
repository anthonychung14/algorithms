/*

PROMPT

Make a search bar that retrieves results from this uri
- http://jsonplaceholder.typicode.com/posts

*/