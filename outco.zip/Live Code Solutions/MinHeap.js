//http://eloquentjavascript.net/1st_edition/appendix2.html

var MinHeap = function(){
  this.storage = [];
}




MinHeap.prototype = {
  swap: function(index1, index2){
    var temp = this.storage[index1];
    this.storage[index1] = this.storage[index2];
    this.storage[index2] = temp;
  }, 
  peak: function(){
    return this.storage[0];
  }, 
  size: function(){
    return this.storage.length;
  }, 
  insert: function(value){
    this.storage.push(value);
    this.bubbleUp(this.storage.length-1);
  }, 
  // we're going to have the remove method take out a 
  // particular value, which is going to require that we 
  // first find where that value exists, then swap it with
  // the last element, pop it off, then run both bubbleUp 
  // and bubbleDown from the index where it was found
  remove: function(removeValue){
    for (var i = 0; i < this.storage.length; i++){
      if (this.storage[i] === removeValue){
        this.swap(i, this.storage.length-1);
        var toReturn = this.storage.pop();
        if (i < this.storage.length){
          this.bubbleUp(i);
          this.bubbleDown(i);
        }
        return toReturn;
      }
    }
    return 'value was not found in minHeap';
  }, 
  pop: function(){
    this.swap(0, this.storage.length-1);
    var toReturn = this.storage.pop();
    this.bubbleDown(0);
    return toReturn;
  }, 
  bubbleUp: function(childIndex){
    var parentIndex;
    while (childIndex > 0){
      if (childIndex%2 === 1){
        parentIndex = (childIndex-1)/2;
      } else if (childIndex%2 === 0){
        parentIndex = (childIndex-2)/2;
      }
      if (this.storage[parentIndex] < this.storage[childIndex]){
        break;
      } 
      this.swap(parentIndex, childIndex);
      childIndex = parentIndex;
    }
  }, 
  bubbleDown: function(parentIndex){
    var childIndex1;
    var childIndex2;

    while (parentIndex < this.storage.length){
      childIndex1 = 2 * parentIndex + 1;
      childIndex2 = 2 * parentIndex + 2;
      // parent: 3

      if (childIndex1 >= this.storage.length){
        break;
      }

      if (childIndex2 < this.storage.length){
        if (this.storage[parentIndex] < this.storage[childIndex1] && this.storage[parentIndex] < this.storage[childIndex2]){
          break;
        } else if (this.storage[parentIndex] > this.storage[childIndex1] && this.storage[parentIndex] > this.storage[childIndex2]){
          if (this.storage[childIndex1] < this.storage[childIndex2]){
            this.swap(childIndex1, parentIndex);
            parentIndex = childIndex1;
          } else {
            this.swap(childIndex2, parentIndex);
            parentIndex = childIndex2;
          }
        } else if (this.storage[parentIndex] > this.storage[childIndex1]){
          this.swap(parentIndex, childIndex1);
            parentIndex = childIndex1;
        } else if (this.storage[parentIndex] > this.storage[childIndex2]){
          this.swap(parentIndex, childIndex2);
            parentIndex = childIndex2;
        }
      } else if (childIndex1 < this.storage.length){
        if (this.storage[parentIndex] > this.storage[childIndex1]){
          this.swap(parentIndex, childIndex1);
            parentIndex = childIndex1;
        } else {
          break;
        }
      }
    }

  }
}




var test = new MinHeap();

var blah = [10,7,4,3,5,9,2,1,6];

blah.forEach(function(element){
  test.insert(element);
})

console.log(test);
console.log("remove: ", test.remove(11));
console.log(test);








