/********************************************************************* 
 *                        Target Practice I                          *
 *                                                                   *
 *               Complexity Analysis - Time & Space                  *
 *                                                                   *
 *  Instructions: List the Time and Space complexity of each         *
 *                of the following functions in the space provided   *
 *                                                                   *
 *********************************************************************/

/**
 * Problem 1:
 *
 *  Time Complexity: O(1)
 *  Auxiliary Space Complexity: O(1)
 **/

function isThereCat(object) {

  while(object['cat']) { // O(1)
    console.log("There is cat!"); // O(1)
    delete object['cat']; // O(1)
  }
  console.log("There is no cat!"); // O(1)
};


/**
 * Problem 2:
 *
 *  Time Complexity: O(1)
 *  Auxiliary Space Complexity: O(1)
 **/

function powerOfThrees(int) {
  var result = []; // O(1)
  var count = 1; // O(1)
  var temp = 1; // O(1)

  while(count <= 3) { // O(1)
    temp *= int; // O(1)
    result.push(temp); // O(1)
    count++; // O(1)
  }

  return result; // O(1)
};

// console.log(powerOfThrees(5));


/**
 * Problem 3:
 *
 *  Time Complexity: O(n^2)
 *  Auxiliary Space Complexity: O(1)
 **/

function findDuplicate(collection) {
  var len = collection.length; // O(1)
  var currItem; // O(1)

  for (var i = 0; i < len; i++) { // O(1)
    currItem = collection[i]; // O(1)

    for (var j = 0; j < len; j++) { // O(1)
      if (j !== i) { // O(1)
        if (currItem === collection[j]) { // O(1)
          return true; // O(1)
        }
      }
    }
  }
  return false; // O(1)
};


/**
 * Problem 4:
 *
 *  Time Complexity: O(mn)
 *  Auxiliary Space Complexity: O(mn)
 **/

function intersectionPoints(array1, array2) {
  var result = []; // O(1)
  var points; // O(1)

  for (var i = 0; i < array1.length; i++) { // O(1)
    for (var j = 0; j < array2.length; j++) { // O(1)
      if (array1[i] === array2[j]) { // O(1)
        points = [array1[i], array2[j]]; // O(1)
        result.push(points); // O(1)
        points = []; // O(1)
      }
    }
  }

  return result; // O(mn)
};

// console.log(intersectionPoints([1,2,3,4,5],[4,5,6,7,8]));


/**
 * Problem 5:
 *
 *  Time Complexity: O(n)
 *  Auxiliary Space Complexity: O(n)
 **/

function nthFibonacci(n) {
  var result = [0,1]; // O(1)

  for(var i = 1; i < n; i++) { // O(1)
    result[i+1] = result[i] + result[i-1]; // O(1)
  }

  return result[n]; // O(n)
};


/************************
 *     Extra Credit     *
 ************************/

/**
 * Extra Credit 1:
 *
 * Problem: Refactor findDuplicate such that it now finds and returns all repeating elements
 *          in O(n) time complexity.
 *
 *          What is the auxiliary space complexity of your solution?
 *
 *          Auxiliary Space Complexity: O(n)
 * 
 *          
 **/

var findDuplicate = function(collection){
  var lib = {};
  var result = {};

  for (var i = 0; i < collection.length; i++){
    if (lib[collection[i]] === undefined){
      lib[collection[i]] = true;
    } else {
      result[collection[i]] = true;
    }
  }

  return Object.keys(result);
}

// console.log(findDuplicate([1,2,3,4,5,6,1,2,3]));

/**
 * Extra Credit 2:
 *
 *  Time Complexity: O(n)
 *  Auxiliary Space Complexity: O(n)
 **/

function nthFibonacci(n){
  var result;
  var cache = {};

  function searchFib(index){
    if (cache[index] !== undefined){
      return cache[index];
    } else if(index < 2){
      return index;
    } else {
      var toInsert = searchFib(index-1) + searchFib(index-2);
      cache[index] = toInsert;
      return cache[index];
    }
  }

  result = searchFib(n);
  return result;
};

// console.log(nthFibonacci(100));

