/********************************************************************* 
 *                       Target Practice VI                          *
 *                                                                   *
 *                        Traversals Pt. 2                           *
 *                                                                   *
 *  Instructions: One of the most fundamental components of working  *
 *                with trees and graphs is traversals.  We will      *
 *                focus primarily on this piece to build your        *
 *                foundation of these data structures.               *
 *                                                                   *
 *********************************************************************/

/**
 *  4. For the example graph below, what is the expected output if we printed each
 *     vertex value from vertex A outwards using:
 *
 *     a. BREADTH FIRST traversal? [A,B,C,D,E,F,G]
 *
 *     b. DEPTH FIRST traversal? [A,B,D,C,E,F,G]
 *
 *     NOTE: Assume the order of edges will be alphabetical. E.g., Vertex D has edges to
 *           5 vertices in the following order: B, C, E, F, G
 *
 *     NOTE: The traversal should take care of redundancy and not print the same vertex
 *           value twice.
 *
 *     Example Graph:
 *
 *              B     E
 *            /   \  /
 *          A       D  --- F
 *            \   /   \   /
 *              C       G
 **/

/*** Next we need a graph.  Use an existing graph class that you have built. ***/

var Vertex = function(id){
  this.value = id;
  this.edges = {};
}

var Graph = function(){
  this.vertices = {};
  this.totalVertices = 0;
  this.totalEdges = 0;
}

Graph.prototype.addVertex = function(id){
  if (this.vertices[id] === undefined){
    var newVertex = new Vertex(id);
    this.vertices[id] = newVertex;
    this.totalVertices++;
  }
}

Graph.prototype.getVertex = function(id){
  if (this.vertices[id] !== undefined){
    return this.vertices[id];
  } else {
    console.log("ID does not exist in graph");
  }
}

Graph.prototype.addEdge = function(id1, id2){
  if (this.vertices[id1] !== undefined && this.vertices[id2] !== undefined){
    if (this.vertices[id1].edges[id2] === undefined && this.vertices[id2].edges[id1] === undefined){
      this.vertices[id1].edges[id2] = id2;
      this.vertices[id2].edges[id1] = id1;
      this.totalEdges++;
    } else {
      console.log('Edge already exists between id1 and id2');
    }
  } else {
    console.log('Either vertex of id1 or id2 or both do not exist in graph');
  }
}

Graph.prototype.removeEdge = function(id1, id2){
  if (this.vertices[id1] !== undefined && this.vertices[id2] !== undefined){
    if (this.vertices[id1].edges[id2] !== undefined && this.vertices[id2].edges[id1] !== undefined){
      delete this.vertices[id1].edges[id2];
      delete this.vertices[id2].edges[id1];
      this.totalEdges--;
    } else {
      console.log('Edge does not exist between id1 and id2');
    }
  } else {
    console.log('Either vertex of id1 or id2 or both do not exist in graph');
  }
}

Graph.prototype.removeVertex = function(id){
  if (this.vertices[id] !== undefined){
    var toDelete = this.vertices[id];
    for (var edge in toDelete.edges){
      this.removeEdge(id, edge);
    }
    delete this.vertices[id];
    this.totalVertices--;
  } else {
    console.log('ID does not exist in graph');
  }
}

Graph.prototype.findNeighbors = function(id){
  var neighbors = [];
  if (this.vertices[id] !== undefined){
    for (var edge in this.vertices[id].edges){
      neighbors.push(this.vertices[edge]);
    }
    return neighbors;
  } else {
    console.log('ID does not exist in graph');
  }
}

Graph.prototype.forEachVertex = function(func){
  for (vertexKey in this.vertices){
    func(this.vertices[vertexKey]);
  }
}

Graph.prototype.forEachEdge = function(func){
  for (vertexKey in this.vertices){
    var vertex = this.vertices[vertexKey];
    for (var edge in vertex.edges){
      func(edge, vertex.value);
    }
  }
}

/**
 *  5a. Build a replica of the example graph in Problem 4. to use as an example.
 **/

var toInsert = ['A','B','C','D','E','F','G']

var work = new Graph();

toInsert.forEach(function(element){
  work.addVertex(element);
})

work.addEdge('A','B');
work.addEdge('A','C');
work.addEdge('B','D');
work.addEdge('C','D');
work.addEdge('D','E');
work.addEdge('D','F');
work.addEdge('D','G');
work.addEdge('F','G');

console.log(work.vertices);


/**
 *  5b. Using a queue and while loop, write a function that takes in a graph and
 *      outputs an array of values from vertex A outwards ordered by BREADTH 
 *      FIRST traversal.
 *
 *  Input: Graph
 *  Output: Array
 *
 *  NOTE: Confirm with your answer from problem 4a.
 *
 *  NOTE: You may use an array or linked list for your queue.
 *
 *  HINT: Use a hash table to handle redundancy
 **/

var breadthFirst = function(graph, start){
  var queue = [];
  var lib = {};
  var result = [];

  queue.push(graph.vertices[start])
  lib[start] = true;
  var cVert;

  while (queue.length > 0){
    cVert = queue.shift();
    for (var edge in cVert.edges){
      if (lib[edge] === undefined){
        queue.push(graph.vertices[edge])
        lib[edge] = true;
      }
    }
    result.push(cVert.value);
  }

  return result;
}

console.log("BREADTH FIRST: ", breadthFirst(work, 'A'))

/**
 *  5c. Using a stack and while loop, write a function that takes in a graph and
 *      outputs an array of values from vertex A outwards ordered by DEPTH 
 *      FIRST traversal.
 *
 *      Input: Graph
 *      Output: Array
 *
 *  NOTE: Confirm with your answer from problem 4b.
 *
 *  NOTE: You may use an array or linked list for your stack.
 *
 *  HINT: Use a hash table to handle redundancy
 **/


 var depthFirst = function(graph, start){
   var stack = [];
   var lib = {};
   var result = [];

   stack.push(graph.vertices[start])
   lib[start] = true;
   var cVert;

   while (stack.length > 0){
     cVert = stack.pop();
     for (var edge in cVert.edges){
       if (lib[edge] === undefined){
         stack.push(graph.vertices[edge])
         lib[edge] = true;
       }
     }
     result.push(cVert.value);
   }

   return result;
 }

console.log('[A,B,D,C,E,F,G]');
console.log("DEPTH FIRST: ", depthFirst(work, 'A'))



// DEPTH FIRST RECURSIVELY
var depthFirstRec = function(graph, startVertexID){
  var result = [];
  var lib = {};

  var traverse = function(cVert){
    if (lib[cVert.value] === true){
      return;
    }
    lib[cVert.value] = true;
    result.push(cVert.value);

    for (var edge in cVert.edges){
      if (lib[edge] === undefined){
        traverse(graph.vertices[edge]);
      }
    }
  }

  traverse(graph.vertices[startVertexID]);

  return result;
}

// [ 'A', 'B', 'D', 'C', 'E', 'F', 'G' ] <-- now it matches
console.log(depthFirstRec(work, 'A'));

