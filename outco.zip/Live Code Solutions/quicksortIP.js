function quicksort(arr){

  function piles(start, end){
    if(end - start <= 0){ return; }
    //pivot is the last index which is just end
    var mid = start;
    for(var i = start; i < end; i++){
      if(arr[i] < arr[end]){
        swap(i, mid);
        mid++;
      }
    }
    swap(end, mid);
    piles(start, mid-1);
    piles(mid+1, end);
  }

  function swap(i, j){
    var temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }

  piles(0, arr.length-1);
  return arr;
}

console.log(quicksort([5,1,0,8,3,4]))
console.log(quicksort([]))
console.log(quicksort([0]))