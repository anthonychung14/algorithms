/********************************************************************* 
 *                           Sprint IV                               *
 *                                                                   *
 *                        Traversals Pt. 1                           *
 *                                                                   *
 *  Instructions: One of the most fundamental components of working  *
 *                with trees and graphs is traversals.  We will      *
 *                focus primarily on this piece to build your        *
 *                foundation of these data structures.               *
 *                                                                   *
 *********************************************************************/

/*** First we need a binary search tree.  Use an existing binary search tree class that you have built. ***/

var node = function(value){
  this.value = value;
  this.right = null;
  this.left = null;
}

var binarySearchTree = function(){
  this.root = null;
  this.size = 0;
}

binarySearchTree.prototype.insert = function(value){
  if (this.root === null){
    // when the tree is empty
    this.root = new node(value);
    this.size++;
  } else {
    // when stuff has already been inserted
    var findAndInsert = function(currentNode){

      if (value > currentNode.value){
        if (currentNode.right === null){
          currentNode.right = new node(value);
        } else {
          findAndInsert(currentNode.right);
        }
      } else if (value < currentNode.value){
        if (currentNode.left === null){
          currentNode.left = new node(value);
        } else {
          findAndInsert(currentNode.left);
        }
      }
    }

    findAndInsert(this.root);

    this.size++;

  }
}

binarySearchTree.prototype.search = function(target){
  var check = false;

  var traverse = function(currentNode){
    if (check){
      return;
    } else if (currentNode === null){
      return;
    } else if (currentNode.value === target){
      check = true;
      return;
    }

    if (target > currentNode.value){
      traverse(currentNode.right);
    } else if (target < currentNode.value){
      traverse(currentNode.left);
    }
  }

  traverse(this.root);
  return check;
}

binarySearchTree.prototype.delete = function(deleteValue){
  var temp = [];

  var roundUp = function(currentNode){
    if (currentNode === null){
      return;
    } else {
      if (currentNode.value !== deleteValue){
        temp.push(currentNode.value);
      }
    }

    roundUp(currentNode.right);
    roundUp(currentNode.left);
  }

  roundUp(this.root);

  if (temp.length === this.size){
    console.log('deleteValue: ' + deleteValue + ' was not found in binary search tree');
    return;
  }

  // create temporary tree
  var tempTree = new binarySearchTree();

  // iterate through all of the found values that weren't the target
  // and insert them into the new tree
  temp.forEach(function(value){
    tempTree.insert(value);
  })

  // reinitialize the root as the tempTree root
  this.root = tempTree.root;

  // reduce size of tree
  this.size--;
  
  console.log(deleteValue + ' has been deleted from the tree');
}

/**
 *  1. Write a function that takes in an array of integers and performs the insert method on each
 *     item of the array in order.
 * 
 *  Input: Array
 *  Output: Binary Search Tree
 *
 *  Example: [4, 2, 5, 1, 3, 7, 6, 8]
 *  Output this binary search tree:
 *
 *              4
 *            /   \
 *          2       5
 *        /   \       \
 *      1       3       7
 *                    /   \
 *                  6      8
 **/

binarySearchTree.prototype.insertMany = function(array){
  for (var i = 0; i < array.length; i++){
    this.insert(array[i]);
  }
}

var test = new binarySearchTree();

test.insertMany([4, 2, 5, 1, 3, 7, 6, 8]);
// console.log(test.root);

/**
 *  2. Given the example output binary search tree from Problem 1, what would the order of values
 *     printed be if we used:
 *
 *     a. BREADTH FIRST traversal [4,2,5,1,3,7,6,8]
 *
 *     b. PRE-ORDER DEPTH first traversal [4,2,1,3,5,7,6,8]
 *
 *     c. IN-ORDER DEPTH first traversal [1,2,3,4,5,6,7,8]
 *
 *     d. POST-ORDER DEPTH first traversal [1,3,2,6,8,7,5,4]
 **/


/**
 *  3a. Using a queue, and while loop write a function that takes in a binary search tree and
 *      outputs an array of values ordered by BREADTH FIRST traversal.
 *
 *  Input: Binary Search Tree
 *  Output: Array
 *
 *  NOTE: You may use an array or linked list for your queue.
 *
 *  NOTE: Confirm with your answer from problem 2a.
 **/

binarySearchTree.prototype.breadthFirst = function(){
  var queue = [];
  var result = [];

  queue.push(this.root);
  var cNode;
  
  while (queue.length > 0){
    cNode = queue.shift();
    if (cNode.left !== null){
      queue.push(cNode.left);
    }
    if (cNode.right !== null){
      queue.push(cNode.right);
    }
    result.push(cNode.value);
  }
  return result;
}

// [4,2,5,1,3,7,6,8]
// console.log(test.breadthFirst());

/**
 *  3b. Using recursion, write a function that takes in a binary search tree and
 *      outputs an array of values ordered by PRE-ORDER DEPTH FIRST traversal.
 *
 *      Input: Binary Search Tree
 *      Output: Array
 *
 *      NOTE: Confirm with your answer from problem 2b.
 **/

binarySearchTree.prototype.preDepth = function(){
  var result = [];

  var traverse = function(cNode){
    if (cNode === null){
      return;
    }


    result.push(cNode.value);
    traverse(cNode.left);
    traverse(cNode.right);

  }
  traverse(this.root);

  return result;
}

// console.log(test.preDepth());


/**
 *  3c. Using recursion, write a function that takes in a binary search tree and
 *      outputs an array of values ordered by IN-ORDER DEPTH FIRST traversal.
 *
 *      Input: Binary Search Tree
 *      Output: Array
 *
 *      NOTE: Confirm with your answer from problem 2c.
 **/

 binarySearchTree.prototype.inDepth = function(){
   var result = [];

   var traverse = function(cNode){
     if (cNode === null){
       return;
     }


     traverse(cNode.left);
     result.push(cNode.value);
     traverse(cNode.right);

   }
   traverse(this.root);

   return result;
 }

/**
 *  3d. Using recursion, write a function that takes in a binary search tree and
 *      outputs an array of values ordered by POST-ORDER DEPTH FIRST traversal.
 *
 *      Input: Binary Search Tree
 *      Output: Array
 *
 *      NOTE: Confirm with your answer from problem 2d.
 **/

 binarySearchTree.prototype.postDepth = function(){
   var result = [];

   var traverse = function(cNode){
     if (cNode === null){
       return;
     }


     traverse(cNode.left);
     traverse(cNode.right);
     result.push(cNode.value);

   }
   traverse(this.root);

   return result;
 }




// how to use pure recursion for depth-first traversal
var pureDepth = function(cNode){
  if (cNode === null){
    return [];
  }

  // return [cNode.value].concat(pureDepth(cNode.left)).concat(pureDepth(cNode.right));
  return (pureDepth(cNode.left)).concat([cNode.value]).concat(pureDepth(cNode.right));
}

console.log(pureDepth(test.root));









