function heapsort(arr){
  
  
  //build up max heap
  function insertElement(index){
    
    //bubble bubbleUP from index
    var child = index;
    var parent = Math.floor((child - 1)/2);
    while(child > 0 && arr[child] > arr[parent]){
      swap(child, parent);
      child = parent;
      parent = Math.floor((child - 1)/2);
    }
  }

  function removeElement(index){
    //swap first and index
    swap(0, index);

    //bubble down until index-1
    var parent = 0;
    var child = getChild(parent);

    while(child < index && arr[parent] < arr[child]){

      //swap with your child
      swap(child, parent);
      //update parent and child
      parent = child;
      child = getChild(parent);
    }

    function getChild(parent){
      var child = 2 * parent + 1;
      if(arr[child + 1] !== undefined && child + 1 < index && arr[child + 1] > arr[child]){
        child++;
      }
      return child;
    }

  }

  function swap(i, j){
    var temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
  }

  for(var i = 0; i < arr.length; i++){
    insertElement(i);
    console.log("inserted at " + i + ": ", arr);
  }

  for(var i = arr.length-1; i > 0; i--){
    removeElement(i);
    console.log("removed with " + i + ": ", arr);
  }

  return arr;
}

console.log(heapsort([4,1,5,8,3,0]));