/********************************************************************** 
 *                        Target Practice II                          *
 *                                                                    *
 *                           Recursion                                *
 *                                                                    *
 *  Instructions: Using recursion work through the following problems *
 *                                                                    *
 **********************************************************************/

/**
 * 1a. What is the term when the recursive call invokes itself more than once.
 **/
// Multiple recursion


/**
 * 1b. List the step by step for building Helper Method Recursion.
 *
 * 1. Instantiate variables
 *    a. track state, results
 * 2. Return results
 * 3. Helper Method
 *    a. Instantiate
 *    b. Invoke
 * 4. Base Case
 * 5. Recursive Case
 **/




/**
 * 1c. Should the recursive case or base case typically be tackled first?
 **/
// Base case


/**
 * 2a. Print each item in an array in order using Helper Method of Recursion
 *
 * Input: Array (or Array List)
 * Output: Undefined
 *
 * Example: print([1,2,3]) => 
 *          1
 *          2
 *          3
 **/

var print = function(input){

  var traverse = function(index){
    // base case
    if (index >= input.length){
      return;
    }

    // action
    console.log(input[index]);

    // recursive case
    traverse(index+1)
  }

  traverse(0);
}

// console.log(print([1,2,3]));

/**
 * 2b. Print each item in an array backwards using Helper Method of Recursion
 *
 * Input: Array (or Array List)
 * Output: Undefined
 *
 * Example: reversePrint([1,2,3]) => 
 *          3
 *          2
 *          1
 **/

var reversePrint = function(input){

  var traverse = function(index){
    // base case
    if (index < 0){
      return;
    }

    // action
    console.log(input[index]);

    // recursive case
    traverse(index-1)
  }

  traverse(input.length-1);
}

// console.log(reversePrint([1,2,3]));


/**
 * 2c. Reverse a string using Helper Method of Recursion
 *
 * Input: String with no spaces
 * Output: String
 *
 * Example: reverseString('hello') => 'olleh'
 **/

var reverseString = function(input){
  var result = '';

  var traverse = function(index){
    if (index < 0){
      return;
    }

    result += input[index];

    traverse(index-1);
  }
  traverse(input.length-1);

  return result;
}

// console.log(reverseString('hello'));

/**
 * 2d. Create two item arrays (tuples) from an array using the Helper Method of Recursion
 *
 * Input: Array of integers
 * Output: Array of two items arrays
 *
 * Example: tuples([1, 2, 3, 4, 5, 6]) => [[1,2], [3,4], [5,6]]
 * Example: tuples([1, 2, 3, 4, 5]) => [[1,2], [3,4], [5, undefined]]
 **/

var tuples = function(collection){
  var results = [];

  var traverse = function(index){
    if (index >= collection.length){
      return;
    }

    var pair = [collection[index], collection[index+1]];
    results.push(pair);

    traverse(index+2);
  }
  traverse(0);

  return results; 
}

// console.log(tuples([1,2,3,4,5,6]));
// console.log(tuples([1,2,3,4,5]));


/**
 * 2e. Flatten a nested array (or array list) using the Helper Method of Recursion
 *
 * Input: Array of integers and arrays
 * Output: Array of integers
 *
 * Example: flatten([1, [2, 3, [4]], 5, [[6]]]) => [1, 2, 3, 4, 5, 6]
 **/

var flatten = function(collection){
  var results = [];

  var traverse = function(element){
    // if it's a number
    if (Number.isInteger(element)){
      results.push(element);
      return;
    } else {
      for (var i = 0; i < element.length; i++){
        traverse(element[i]);
      }
    }
  }
  traverse(collection);

  return results;
}

// console.log(flatten([1, [2, 3, [4]], 5, [[6]]]))


/**
 * 2f. Power using Helper Method of Recursion
 *
 * Input: Two Integers, Base and Exponent
 * Output: Integer of result 
 *
 * Example: power(3, 4) => 81
 **/

var power = function(base, exponent){
  var work = 1;

  var multiply = function(count){
    if (count >= exponent){
      return;
    }

    work = work * base;

    multiply(count+1);
  }
  multiply(0);

  return work;
}

// console.log(power(3,4));

/**
 * 2g. Merge two sorted arrays (or array lists) using the Helper Method of Recursion
 * 
 * Input: 2 Sorted Arrays
 * Output: Sorted Array
 *
 * Example: merge([1, 4, 7],[2, 3, 6, 9]) => [1, 2, 3, 4, 6, 7, 9]
 **/

var merge = function(arr1, arr2){
  var result = [];

  if (arr1.length === 0){
    return arr2;
  } else if (arr2.length === 0){
    return arr1;
  }

  var traverse = function(index1, index2){
    if (index1 >= arr1.length){
      result = result.concat(arr2.slice(index2));
      return;
    } else if (index2 >= arr2.length){
      result = result.concat(arr1.slice(index1));
      return;
    }

    if (arr1[index1] < arr2[index2]){
      result.push(arr1[index1]);
      traverse(index1+1, index2);
    } else {
      result.push(arr2[index2]);
      traverse(index1, index2+1);
    }
  }
  traverse(0, 0);

  return result;
}

console.log(merge([1, 4, 7],[2, 3, 6, 9]))

